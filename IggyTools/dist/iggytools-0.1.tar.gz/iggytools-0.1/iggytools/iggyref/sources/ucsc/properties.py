
# UCSC repository properties

repoProperties = dict(
    selectedCollections = ['human', 'worm', 'yeast'],
    ftpSite = 'hgdownload.cse.ucsc.edu',
    ftpPath = 'goldenPath'
)



