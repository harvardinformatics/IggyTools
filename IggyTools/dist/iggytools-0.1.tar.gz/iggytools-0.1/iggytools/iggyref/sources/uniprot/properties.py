
# Uniprot repository properties

repoProperties = dict(
    selectedCollections = ['uniref100'],
    ftpSite = 'ftp.uniprot.org',
    ftpPath = 'pub/databases/uniprot/current_release'
)

