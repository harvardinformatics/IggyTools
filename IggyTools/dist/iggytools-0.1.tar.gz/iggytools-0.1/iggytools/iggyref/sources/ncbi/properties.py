
# NCBI repository properties

repoProperties = dict(
    selectedCollections = ['nr', 'nt', 'swissprot', 'refseq_genomic', 'refseq_protein', 'refseq_rna'],
    ftpSite = 'ftp.ncbi.nih.gov'
)

