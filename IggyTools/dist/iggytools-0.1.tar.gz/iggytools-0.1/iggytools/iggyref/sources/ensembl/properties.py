
# Ensembl repository properties

repoProperties = dict(
    selectedCollections = ['human', 'fruitfly', 'worm', 'yeast'],
    ftpSite = 'ftp.ensembl.org',
    ftpPath = 'pub'
)

