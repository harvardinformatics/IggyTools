
# ebi repository properties

repoProperties = dict(
    selectedCollections = ['interpro'],
    ftpSite = 'ftp.ebi.ac.uk',
    ftpPath = 'pub'
)

